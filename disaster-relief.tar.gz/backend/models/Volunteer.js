const mongoose = require('mongoose');

const VolunteerSchema = new mongoose.Schema({
  name:           { type: String, required: true },
  email:          { type: String, unique: true, sparse: true },
  phone:          { type: String },
  lat:            { type: Number, required: true },
  lng:            { type: Number, required: true },
  skill:          { type: String, enum: ['medical','rescue','logistics'], required: true },
  available:      { type: Boolean, default: true },
  assignedZoneId: { type: mongoose.Schema.Types.ObjectId, ref: 'Zone', default: null },
  organization:   { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('Volunteer', VolunteerSchema);
