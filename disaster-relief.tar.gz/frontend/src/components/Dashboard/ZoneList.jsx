import { getPriorityBg, getPriorityLevel, getSkillIcon } from '../../utils/priority'
import { Trash2 } from 'lucide-react'
import { deleteZone } from '../../utils/api'
import toast from 'react-hot-toast'

export default function ZoneList({ zones, onRefresh }) {
  const sorted = [...zones].sort((a, b) => b.priorityScore - a.priorityScore)

  async function handleDelete(id) {
    try {
      await deleteZone(id)
      toast.success('Zone removed')
      onRefresh()
    } catch {
      toast.error('Failed to delete zone')
    }
  }

  return (
    <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
      <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wide mb-3">
        Priority Queue — Disaster Zones
      </h2>
      <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
        {sorted.length === 0 && (
          <p className="text-slate-500 text-sm text-center py-6">No active zones</p>
        )}
        {sorted.map((zone, idx) => (
          <div
            key={zone._id}
            className="flex items-center gap-3 bg-slate-900/50 rounded-lg px-3 py-2 border border-slate-700/30"
          >
            {/* Rank */}
            <span className="text-slate-500 font-mono text-xs w-4">#{idx + 1}</span>

            {/* Priority bar */}
            <div className="w-1 h-10 rounded-full flex-shrink-0"
              style={{ background: zone.priorityScore >= 7 ? '#ef4444' : zone.priorityScore >= 5 ? '#f59e0b' : '#3b82f6' }}
            />

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white truncate">{zone.name}</div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className={`text-xs px-1.5 py-0.5 rounded ${getPriorityBg(zone.priorityScore)}`}>
                  {getPriorityLevel(zone.priorityScore).toUpperCase()}
                </span>
                <span className="text-xs text-slate-400">
                  {getSkillIcon(zone.requiredSkill)} {zone.requiredSkill}
                </span>
                <span className="text-xs text-slate-500">{zone.peopleAffected?.toLocaleString()} affected</span>
              </div>
            </div>

            {/* Score */}
            <div className="text-right flex-shrink-0">
              <div className="text-sm font-bold text-white">{zone.priorityScore?.toFixed(1)}</div>
              <div className="text-xs text-slate-500">score</div>
            </div>

            {/* Severity bar */}
            <div className="w-16 flex-shrink-0">
              <div className="text-xs text-slate-500 mb-1">Sev {zone.severity}/10</div>
              <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${zone.severity * 10}%`,
                    background: zone.severity >= 8 ? '#ef4444' : zone.severity >= 5 ? '#f59e0b' : '#3b82f6'
                  }}
                />
              </div>
            </div>

            <button
              onClick={() => handleDelete(zone._id)}
              className="text-slate-600 hover:text-red-400 transition-colors flex-shrink-0"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
