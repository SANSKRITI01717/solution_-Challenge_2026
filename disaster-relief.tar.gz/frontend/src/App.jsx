import { Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { SocketProvider } from './context/SocketContext'
import Sidebar from './components/Sidebar'
import Dashboard from './pages/Dashboard'
import Volunteers from './pages/Volunteers'
import OfflineMode from './pages/OfflineMode'

export default function App() {
  return (
    <SocketProvider>
      <div className="flex min-h-screen bg-slate-900">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <Routes>
            <Route path="/"           element={<Dashboard />} />
            <Route path="/volunteers" element={<Volunteers />} />
            <Route path="/offline"    element={<OfflineMode />} />
          </Routes>
        </main>
      </div>

      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#1e293b',
            color: '#f1f5f9',
            border: '1px solid #334155',
            fontSize: 13,
          },
        }}
      />
    </SocketProvider>
  )
}
