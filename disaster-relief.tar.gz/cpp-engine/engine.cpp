#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <algorithm>
#include <cmath>
#include <string>
#include <sstream>
#include <fstream>
#include <climits>
#include <set>

// ─────────────────────────────────────────────
//  DATA STRUCTURES
// ─────────────────────────────────────────────

struct Coordinate {
    double lat, lng;
};

double euclideanDistance(const Coordinate& a, const Coordinate& b) {
    double dlat = a.lat - b.lat;
    double dlng = a.lng - b.lng;
    return std::sqrt(dlat * dlat + dlng * dlng);
}

// Haversine distance in km (for real-world accuracy)
double haversineDistance(const Coordinate& a, const Coordinate& b) {
    const double R = 6371.0;
    double dLat = (b.lat - a.lat) * M_PI / 180.0;
    double dLng = (b.lng - a.lng) * M_PI / 180.0;
    double sinLat = std::sin(dLat / 2);
    double sinLng = std::sin(dLng / 2);
    double h = sinLat * sinLat +
               std::cos(a.lat * M_PI / 180.0) *
               std::cos(b.lat * M_PI / 180.0) *
               sinLng * sinLng;
    return 2 * R * std::asin(std::sqrt(h));
}

struct DisasterZone {
    std::string id;
    std::string name;
    Coordinate  coord;
    int         severity;        // 1-10
    int         peopleAffected;
    std::string requiredSkill;   // medical | rescue | logistics
    double      priorityScore;
    bool        needsHelp;

    // Priority = severity*0.5 + log(people)*0.3 + severity/10*0.2
    void calcPriority() {
        double peopleFactor = (peopleAffected > 0)
            ? std::log(static_cast<double>(peopleAffected) + 1) * 0.3
            : 0;
        priorityScore = severity * 0.5 + peopleFactor + (severity / 10.0) * 0.2;
    }
};

struct Volunteer {
    std::string id;
    std::string name;
    Coordinate  coord;
    std::string skill;   // medical | rescue | logistics
    bool        available;
    std::string assignedZoneId;
};

struct Resource {
    std::string id;
    std::string type;   // food | medicine | shelter
    int         quantity;
    Coordinate  coord;
    std::string ngoId;
};

struct Assignment {
    std::string volunteerId;
    std::string zoneId;
    double      distanceKm;
    std::string skill;
};

// ─────────────────────────────────────────────
//  1. PRIORITY QUEUE (MAX-HEAP)
//     Always process the most urgent zone first
// ─────────────────────────────────────────────

struct ZoneComparator {
    bool operator()(const DisasterZone* a, const DisasterZone* b) const {
        return a->priorityScore < b->priorityScore; // max-heap
    }
};

using ZonePQ = std::priority_queue<
    DisasterZone*,
    std::vector<DisasterZone*>,
    ZoneComparator
>;

ZonePQ buildPriorityQueue(std::vector<DisasterZone>& zones) {
    ZonePQ pq;
    for (auto& z : zones) {
        z.calcPriority();
        if (z.needsHelp) pq.push(&z);
    }
    return pq;
}

// ─────────────────────────────────────────────
//  2. GRAPH + DIJKSTRA
//     Find shortest path from zone to volunteers
//     Nodes = zones + volunteer locations
// ─────────────────────────────────────────────

struct GraphNode {
    std::string id;
    Coordinate  coord;
    std::string type; // "zone" | "volunteer"
};

struct Edge {
    int    to;
    double weight; // distance in km
};

class Graph {
public:
    std::vector<GraphNode>        nodes;
    std::vector<std::vector<Edge>> adj;

    int addNode(const GraphNode& n) {
        nodes.push_back(n);
        adj.push_back({});
        return static_cast<int>(nodes.size()) - 1;
    }

    void addEdge(int u, int v, double w) {
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});
    }

    // Build complete graph: every node connected to every other
    void buildComplete() {
        int n = static_cast<int>(nodes.size());
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                double d = haversineDistance(nodes[i].coord, nodes[j].coord);
                addEdge(i, j, d);
            }
        }
    }

    // Dijkstra from src — returns distances to all nodes
    std::vector<double> dijkstra(int src) {
        int n = static_cast<int>(nodes.size());
        std::vector<double> dist(n, 1e18);
        std::priority_queue<
            std::pair<double, int>,
            std::vector<std::pair<double, int>>,
            std::greater<>
        > pq;
        dist[src] = 0.0;
        pq.push({0.0, src});

        while (!pq.empty()) {
            auto [d, u] = pq.top(); pq.pop();
            if (d > dist[u]) continue;
            for (auto& e : adj[u]) {
                if (dist[u] + e.weight < dist[e.to]) {
                    dist[e.to] = dist[u] + e.weight;
                    pq.push({dist[e.to], e.to});
                }
            }
        }
        return dist;
    }
};

// ─────────────────────────────────────────────
//  3. GREEDY MATCHER
//     For each zone (sorted by priority desc):
//       - Filter volunteers by required skill
//       - Pick the nearest available one
//       - Assign and mark them busy
// ─────────────────────────────────────────────

std::vector<Assignment> greedyMatch(
    std::vector<DisasterZone>& zones,
    std::vector<Volunteer>&    volunteers
) {
    // Build graph
    Graph g;
    std::unordered_map<std::string, int> idToIndex;

    for (auto& z : zones) {
        if (!z.needsHelp) continue;
        int idx = g.addNode({z.id, z.coord, "zone"});
        idToIndex[z.id] = idx;
    }
    for (auto& v : volunteers) {
        int idx = g.addNode({v.id, v.coord, "volunteer"});
        idToIndex[v.id] = idx;
    }
    g.buildComplete();

    // Sort zones by priority descending (greedy: most urgent first)
    std::vector<DisasterZone*> sortedZones;
    for (auto& z : zones) {
        if (z.needsHelp) sortedZones.push_back(&z);
    }
    std::sort(sortedZones.begin(), sortedZones.end(),
        [](const DisasterZone* a, const DisasterZone* b) {
            return a->priorityScore > b->priorityScore;
        });

    std::vector<Assignment> assignments;

    for (auto* zone : sortedZones) {
        int zoneIdx = idToIndex.count(zone->id) ? idToIndex[zone->id] : -1;
        if (zoneIdx < 0) continue;

        // Dijkstra from this zone
        auto dists = g.dijkstra(zoneIdx);

        // Filter: available volunteers with matching skill
        double   bestDist = 1e18;
        Volunteer* bestVol = nullptr;
        int        bestIdx = -1;

        for (auto& vol : volunteers) {
            if (!vol.available) continue;
            if (vol.skill != zone->requiredSkill && zone->requiredSkill != "any") continue;
            int vIdx = idToIndex.count(vol.id) ? idToIndex[vol.id] : -1;
            if (vIdx < 0) continue;
            if (dists[vIdx] < bestDist) {
                bestDist = dists[vIdx];
                bestVol  = &vol;
                bestIdx  = vIdx;
            }
        }

        if (bestVol) {
            bestVol->available       = false;
            bestVol->assignedZoneId  = zone->id;
            assignments.push_back({
                bestVol->id,
                zone->id,
                bestDist,
                bestVol->skill
            });
        }
    }

    return assignments;
}

// ─────────────────────────────────────────────
//  SIMPLE JSON PARSER (no external deps)
//  Parses flat key:"value" pairs from JSON
// ─────────────────────────────────────────────

std::string jsonGetString(const std::string& json, const std::string& key) {
    std::string search = "\"" + key + "\"";
    size_t pos = json.find(search);
    if (pos == std::string::npos) return "";
    pos = json.find(':', pos + search.size());
    if (pos == std::string::npos) return "";
    size_t start = json.find('"', pos + 1);
    if (start == std::string::npos) return "";
    size_t end = json.find('"', start + 1);
    if (end == std::string::npos) return "";
    return json.substr(start + 1, end - start - 1);
}

double jsonGetDouble(const std::string& json, const std::string& key) {
    std::string search = "\"" + key + "\"";
    size_t pos = json.find(search);
    if (pos == std::string::npos) return 0.0;
    pos = json.find(':', pos + search.size());
    if (pos == std::string::npos) return 0.0;
    size_t start = pos + 1;
    while (start < json.size() && (json[start]==' '||json[start]=='\t')) start++;
    size_t end = start;
    while (end < json.size() && (isdigit(json[end])||json[end]=='.'||json[end]=='-')) end++;
    if (start == end) return 0.0;
    return std::stod(json.substr(start, end - start));
}

bool jsonGetBool(const std::string& json, const std::string& key) {
    std::string search = "\"" + key + "\"";
    size_t pos = json.find(search);
    if (pos == std::string::npos) return false;
    pos = json.find(':', pos + search.size());
    if (pos == std::string::npos) return false;
    size_t start = pos + 1;
    while (start < json.size() && (json[start]==' '||json[start]=='\t')) start++;
    return json.substr(start, 4) == "true";
}

// Split JSON array string into individual object strings
std::vector<std::string> splitJsonArray(const std::string& json, const std::string& key) {
    std::vector<std::string> result;
    std::string search = "\"" + key + "\"";
    size_t pos = json.find(search);
    if (pos == std::string::npos) return result;
    pos = json.find('[', pos);
    if (pos == std::string::npos) return result;

    int depth = 0;
    size_t objStart = std::string::npos;
    for (size_t i = pos; i < json.size(); i++) {
        if (json[i] == '{') {
            if (depth == 0) objStart = i;
            depth++;
        } else if (json[i] == '}') {
            depth--;
            if (depth == 0 && objStart != std::string::npos) {
                result.push_back(json.substr(objStart, i - objStart + 1));
                objStart = std::string::npos;
            }
        } else if (json[i] == ']' && depth == 0) {
            break;
        }
    }
    return result;
}

// ─────────────────────────────────────────────
//  JSON OUTPUT BUILDER
// ─────────────────────────────────────────────

std::string escapeJson(const std::string& s) {
    std::string out;
    for (char c : s) {
        if (c == '"')  out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else out += c;
    }
    return out;
}

std::string buildOutput(
    const std::vector<DisasterZone>&  zones,
    const std::vector<Volunteer>&     volunteers,
    const std::vector<Assignment>&    assignments
) {
    std::ostringstream o;
    o << "{\n";

    // Sorted zones
    o << "  \"prioritizedZones\": [\n";
    std::vector<const DisasterZone*> sz;
    for (auto& z : zones) sz.push_back(&z);
    std::sort(sz.begin(), sz.end(), [](auto a, auto b){
        return a->priorityScore > b->priorityScore;
    });
    for (size_t i = 0; i < sz.size(); i++) {
        auto* z = sz[i];
        o << "    {\"id\":\"" << escapeJson(z->id)
          << "\",\"name\":\"" << escapeJson(z->name)
          << "\",\"priorityScore\":" << z->priorityScore
          << ",\"severity\":" << z->severity
          << ",\"peopleAffected\":" << z->peopleAffected
          << ",\"requiredSkill\":\"" << escapeJson(z->requiredSkill)
          << "\",\"needsHelp\":" << (z->needsHelp ? "true" : "false")
          << ",\"lat\":" << z->coord.lat
          << ",\"lng\":" << z->coord.lng
          << "}";
        if (i + 1 < sz.size()) o << ",";
        o << "\n";
    }
    o << "  ],\n";

    // Assignments
    o << "  \"assignments\": [\n";
    for (size_t i = 0; i < assignments.size(); i++) {
        auto& a = assignments[i];
        o << "    {\"volunteerId\":\"" << escapeJson(a.volunteerId)
          << "\",\"zoneId\":\"" << escapeJson(a.zoneId)
          << "\",\"distanceKm\":" << a.distanceKm
          << ",\"skill\":\"" << escapeJson(a.skill) << "\"}";
        if (i + 1 < assignments.size()) o << ",";
        o << "\n";
    }
    o << "  ],\n";

    // Volunteer status
    o << "  \"volunteerStatus\": [\n";
    for (size_t i = 0; i < volunteers.size(); i++) {
        auto& v = volunteers[i];
        o << "    {\"id\":\"" << escapeJson(v.id)
          << "\",\"name\":\"" << escapeJson(v.name)
          << "\",\"available\":" << (v.available ? "true" : "false")
          << ",\"skill\":\"" << escapeJson(v.skill)
          << "\",\"assignedZoneId\":\"" << escapeJson(v.assignedZoneId)
          << "\",\"lat\":" << v.coord.lat
          << ",\"lng\":" << v.coord.lng
          << "}";
        if (i + 1 < volunteers.size()) o << ",";
        o << "\n";
    }
    o << "  ],\n";

    // Stats
    int assigned = static_cast<int>(assignments.size());
    int unmatched = 0;
    for (auto& z : zones) {
        if (z.needsHelp) {
            bool found = false;
            for (auto& a : assignments) if (a.zoneId == z.id) { found = true; break; }
            if (!found) unmatched++;
        }
    }
    o << "  \"stats\": {"
      << "\"totalZones\":" << zones.size()
      << ",\"assignedZones\":" << assigned
      << ",\"unmatchedZones\":" << unmatched
      << ",\"availableVolunteers\":" << (volunteers.size() - assigned)
      << "}\n";

    o << "}\n";
    return o.str();
}

// ─────────────────────────────────────────────
//  MAIN — reads JSON from stdin, writes to stdout
//  Works both online (piped from Node.js)
//  and offline (piped from local file)
// ─────────────────────────────────────────────

int main() {
    // Read all stdin
    std::ostringstream buffer;
    buffer << std::cin.rdbuf();
    std::string input = buffer.str();

    if (input.empty()) {
        std::cerr << "{\"error\":\"No input provided\"}\n";
        return 1;
    }

    std::vector<DisasterZone> zones;
    std::vector<Volunteer>    volunteers;
    std::vector<Resource>     resources;

    // Parse zones
    for (auto& obj : splitJsonArray(input, "zones")) {
        DisasterZone z;
        z.id             = jsonGetString(obj, "id");
        z.name           = jsonGetString(obj, "name");
        z.coord.lat      = jsonGetDouble(obj, "lat");
        z.coord.lng      = jsonGetDouble(obj, "lng");
        z.severity       = static_cast<int>(jsonGetDouble(obj, "severity"));
        z.peopleAffected = static_cast<int>(jsonGetDouble(obj, "peopleAffected"));
        z.requiredSkill  = jsonGetString(obj, "requiredSkill");
        z.needsHelp      = jsonGetBool(obj, "needsHelp");
        if (z.needsHelp && z.id.empty()) z.needsHelp = false;
        z.calcPriority();
        if (!z.id.empty()) zones.push_back(z);
    }

    // Parse volunteers
    for (auto& obj : splitJsonArray(input, "volunteers")) {
        Volunteer v;
        v.id        = jsonGetString(obj, "id");
        v.name      = jsonGetString(obj, "name");
        v.coord.lat = jsonGetDouble(obj, "lat");
        v.coord.lng = jsonGetDouble(obj, "lng");
        v.skill     = jsonGetString(obj, "skill");
        v.available = jsonGetBool(obj, "available");
        v.assignedZoneId = "";
        if (!v.id.empty()) volunteers.push_back(v);
    }

    if (zones.empty() || volunteers.empty()) {
        std::cerr << "{\"error\":\"Need at least one zone and one volunteer\"}\n";
        return 1;
    }

    // Run greedy matching
    auto assignments = greedyMatch(zones, volunteers);

    // Output JSON result
    std::cout << buildOutput(zones, volunteers, assignments);
    return 0;
}
